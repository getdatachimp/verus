def dc_eval(source,env_dict):return eval(source,env_dict)
def dc_exec(source,env_dict,locals=None):return exec(source,env_dict,locals)