Y='workflow'
X='eval'
W='get_args'
V='combinations'
P='exec'
O='code_snippets'
N='df'
K='<string>'
J=str
H='id'
G='code'
F=compile
E=isinstance
D=False
C=True
A=None
import linecache as Z
from dataclasses import dataclass as Q,asdict as a
from graphlib import TopologicalSorter as c
from inspect import getsource as R
import typing as b
from functools import wraps as S
import ast as B,json as I,pandas as L,re
from data_chimp_executor import open
from itertools import combinations as T
from IPython.display import display as U
def on_execute_cell(H,J,E):
	B=E.copy();C=I.loads(H,strict=D);C['target_id']='main_cmd';F=l(C[G],E)
	if F is not A:B[N]=F[1]
	B['dc_code']=C[G];e(J,B,F);K=d(C[G]);E.update({A:C for(A,C)in B.items()if A.startswith('_o')});return I.dumps({'contains_func_definition':K})
def d(code):
	try:
		A=B.parse(code)
		for F in B.walk(A):
			if E(F,B.FunctionDef):return C
	finally:return D
def e(json_automations,globals_dict,optional_df):
	E=globals_dict;B=optional_df;F=I.loads(json_automations,strict=D)
	for C in F:f(C,E,{H:C[H],'optional_df':B,O:o(C[G],B[0],B[1],E)if B is not A and B[0]is not A and B[1]is not A else A})
def f(cmd,globals_dict,metadata=A):g(cmd,globals_dict,metadata)
def g(cmd,globals_dict,metadata):
	D=metadata;A=globals_dict;C=B.parse(cmd[G])
	if h(C):E={};open.dc_exec(F(C,K,mode=P),A|{V:T},E);i(A|E,D)
	else:open.dc_exec(F(C,K,mode=P),A);j(C,A,D)
def h(root):
	A=D;F=D
	for G in B.walk(root):
		if not E(G,B.FunctionDef):continue
		match G.name:
			case'get_args':A=C
			case'visualize':F=C
	return A and F
def i(dict,metadata):
	B=dict[N];F=dict[W](B)
	for (D,G) in enumerate(F):A=metadata.copy();A['parent_id']=A[H];A[H]=A[H]+f"_{D}";A[O]=A[O][D];A['transient']=C;E=dict['visualize'](B,G);U(E.figure,metadata=A);E.clear()
def j(root,globals_dict,metadata):
	C=root.body.pop()
	if E(C,B.Assign):return A
	try:D=B.Expression(C.value);G=F(D,K,mode=X);U(open.dc_eval(G,globals_dict),metadata=metadata)
	except:return A
class k(B.NodeVisitor):
	def __init__(B,global_dict):B.globals_dict=global_dict;B.result=A
	def visit_Name(A,node):
		B=node;C=open.dc_eval(B.id,A.globals_dict)
		if E(C,L.DataFrame):A.result=B.id,open.dc_eval(B.id,A.globals_dict)
		else:A.generic_visit(B)
	def visit_Expr(A,node):
		C=B.Expression(node.value);G=F(C,K,mode=X);D=open.dc_eval(G,A.globals_dict)
		if E(D,L.DataFrame):A.result=B.unparse(C),D
		else:A.generic_visit(node)
def l(source,globals_dict):
	try:D=B.parse(source);C=k(globals_dict);C.visit(D);return C.result
	except:return A
class m(B.NodeTransformer):
	def __init__(A,args):A.args=args
	def visit_Subscript(C,node):
		A=node;C.generic_visit(A)
		if E(A.value,B.Name)and A.value.id=='args':D=A.slice.value;return B.Constant(C.args[D])
		else:return A
class n(B.NodeVisitor):
	def __init__(A,source_code,og_df_expression,og_df,global_dict):A.source_code=source_code;A.og_df_expression=og_df_expression;A.og_df=og_df;A.has_get_args_func=D;A.has_visualization_func=D;A.global_dict=global_dict
	def visit_FunctionDef(A,node):
		B=node
		match B.name:
			case'get_args':A.has_get_args_func=C;pass
			case'visualize':A.has_visualization_func=C;A.visualization_func_body=B.body;pass
		A.generic_visit(B)
	def code(C):
		if not C.has_get_args_func or not C.has_visualization_func:return A
		D={};open.dc_exec(C.source_code,C.global_dict|{V:T},D);E=D[W](C.og_df);F=[(A,B.parse(B.unparse(C.visualization_func_body)))for A in E];G=[m(A).visit(B)for(A,B)in F];H=[B.unparse(A)for A in G];return[A.replace('return ','').replace(N,C.og_df_expression)for A in H]
def o(code,og_df_expression,og_df,globals_dict):C=og_df_expression;A=code;E=B.parse(A);D=n(A,C,og_df,globals_dict);D.visit(E);return D.code()or re.sub('^df',C,A)
@Q(frozen=C)
class M:name:J;source:J;depends_on:J=A
@Q
class p:
	func:b.Callable;type:J;node:M=A;sorter=A;_sorted=A
	@property
	def sorted(self):
		B=self
		if B._sorted is A:
			C=[];B.sorter.prepare()
			while B.sorter.is_active():D=B.sorter.get_ready();C.append(D);B.sorter.done(*(D))
			B._sorted=C
		return B._sorted
	def __call__(A,*B,**C):return A.func(*(B),**C)
	def __rshift__(B,b):C=M(B.func.__name__,R(B.func))if B.node is A else B.node;D=M(b.func.__name__,R(b.func),C.name);E=B.sorter if B.sorter is not A else c();E.add(D,C);b.sorter=E;b.node=D;return b
	def spec(A):return I.dumps([list(map(a,B))for B in A.sorted])
def task(f):
	@S(f)
	def A(*A,**B):return f(*(A),**B)
	return p(A,'task')
def workflow(f):
	@S(f)
	def A(*A,**B):return f(*(A),**B)
	A.__dc_type=Y;return A
def get_spec_from_module(str,dict):
	B='tmp_dc';G=F(str,B,P);Z.cache[B]=len(str),A,str.splitlines(C),B;D=dict.copy();open.dc_exec(G,D);E=[B for B in D.values()if callable(B)and getattr(B,'__dc_type',A)==Y]
	if len(E)<1:raise Exception('No workflows found')
	return E[0]().spec()
def read_df(name,default=A):return L.DataFrame({'n_distinct_species':[5]})
def persist_df(name,df):0
def check_penguins(df):return df['species'].value_counts()