j='workflow'
i='task'
h='eval'
g='get_args'
f='combinations'
X='exec'
W='code_snippets'
V='df'
U=list
R='cells'
Q='source'
P='<string>'
O=open
N=str
M='id'
L='code'
K=len
J=map
I=compile
H='\n'
F=False
E=True
C=isinstance
B=None
import linecache as k
from dataclasses import dataclass as Y,asdict as l
from graphlib import TopologicalSorter as m
from inspect import getsource as Z
from textwrap import dedent as a
import os,typing as n
from functools import wraps as b
import ast as A,json as G,pandas as S,re
from data_chimp_executor import open as D
from itertools import combinations as c
from IPython.display import display as d
def on_execute_cell(H,I,D):
	A=D.copy();C=G.loads(H,strict=F);C['target_id']='main_cmd';E=w(C[L],D)
	if E is not B:A[V]=E[1]
	A['dc_code']=C[L];p(I,A,E);J=o(C[L]);D.update({B:C for(B,C)in A.items()if B.startswith('_o')});return G.dumps({'contains_func_definition':J})
def o(code):
	try:
		B=A.parse(code)
		for D in A.walk(B):
			if C(D,A.FunctionDef):return E
	finally:return F
def p(json_automations,globals_dict,optional_df):
	D=globals_dict;A=optional_df;E=G.loads(json_automations,strict=F)
	for C in E:q(C,D,{M:C[M],'optional_df':A,W:z(C[L],A[0],A[1],D)if A is not B and A[0]is not B and A[1]is not B else B})
def q(cmd,globals_dict,metadata=B):r(cmd,globals_dict,metadata)
def r(cmd,globals_dict,metadata):
	E=metadata;B=globals_dict;C=A.parse(cmd[L])
	if s(C):F={};D.dc_exec(I(C,P,mode=X),B|{f:c},F);t(B|F,E)
	else:D.dc_exec(I(C,P,mode=X),B);u(C,B,E)
def s(root):
	B=F;D=F
	for G in A.walk(root):
		if not C(G,A.FunctionDef):continue
		match G.name:
			case'get_args':B=E
			case'visualize':D=E
	return B and D
def t(dict,metadata):
	B=dict[V];F=dict[g](B)
	for (C,G) in enumerate(F):A=metadata.copy();A['parent_id']=A[M];A[M]=A[M]+f"_{C}";A[W]=A[W][C];A['transient']=E;D=dict['visualize'](B,G);d(D.figure,metadata=A);D.clear()
def u(root,globals_dict,metadata):
	E=root.body.pop()
	if C(E,A.Assign):return B
	try:F=A.Expression(E.value);G=I(F,P,mode=h);d(D.dc_eval(G,globals_dict),metadata=metadata)
	except:return B
class v(A.NodeVisitor):
	def __init__(A,global_dict):A.globals_dict=global_dict;A.result=B
	def visit_Name(A,node):
		B=node;E=D.dc_eval(B.id,A.globals_dict)
		if C(E,S.DataFrame):A.result=B.id,D.dc_eval(B.id,A.globals_dict)
		else:A.generic_visit(B)
	def visit_Expr(B,node):
		E=A.Expression(node.value);G=I(E,P,mode=h);F=D.dc_eval(G,B.globals_dict)
		if C(F,S.DataFrame):B.result=A.unparse(E),F
		else:B.generic_visit(node)
def w(source,globals_dict):
	try:D=A.parse(source);C=v(globals_dict);C.visit(D);return C.result
	except:return B
class x(A.NodeTransformer):
	def __init__(A,args):A.args=args
	def visit_Subscript(D,node):
		B=node;D.generic_visit(B)
		if C(B.value,A.Name)and B.value.id=='args':E=B.slice.value;return A.Constant(D.args[E])
		else:return B
class y(A.NodeVisitor):
	def __init__(A,source_code,og_df_expression,og_df,global_dict):A.source_code=source_code;A.og_df_expression=og_df_expression;A.og_df=og_df;A.has_get_args_func=F;A.has_visualization_func=F;A.global_dict=global_dict
	def visit_FunctionDef(A,node):
		B=node
		match B.name:
			case'get_args':A.has_get_args_func=E;pass
			case'visualize':A.has_visualization_func=E;A.visualization_func_body=B.body;pass
		A.generic_visit(B)
	def code(C):
		if not C.has_get_args_func or not C.has_visualization_func:return B
		E={};D.dc_exec(C.source_code,C.global_dict|{f:c},E);F=E[g](C.og_df);G=[(B,A.parse(A.unparse(C.visualization_func_body)))for B in F];H=[x(A).visit(B)for(A,B)in G];I=[A.unparse(B)for B in H];return[A.replace('return ','').replace(V,C.og_df_expression)for A in I]
def z(code,og_df_expression,og_df,globals_dict):C=og_df_expression;B=code;E=A.parse(B);D=y(B,C,og_df,globals_dict);D.visit(E);return D.code()or re.sub('^df',C,B)
@Y(frozen=E)
class T:name:N;source:N;depends_on:N=B
@Y
class A0:
	func:n.Callable;type:N;node:T=B;sorter=B;_sorted=B
	@property
	def sorted(self):
		A=self
		if A._sorted is B:
			C=[];A.sorter.prepare()
			while A.sorter.is_active():D=A.sorter.get_ready();C.append(D);A.sorter.done(*(D))
			A._sorted=C
		return A._sorted
	def __call__(A,*B,**C):return A.func(*(B),**C)
	def __rshift__(A,b):C=T(A.func.__name__,Z(A.func))if A.node is B else A.node;D=T(b.func.__name__,Z(b.func),C.name);E=A.sorter if A.sorter is not B else m();E.add(D,C);b.sorter=E;b.node=D;return b
	def spec(A):return G.dumps([U(J(l,B))for B in A.sorted])
def task(f):
	@b(f)
	def A(*A,**B):return f(*(A),**B)
	return A0(A,i)
def workflow(f):
	@b(f)
	def A(*A,**B):return f(*(A),**B)
	A.__dc_type=j;return A
def get_spec_from_module(str,dict):
	A='tmp_dc';G=I(str,A,X);k.cache[A]=K(str),B,str.splitlines(E),A;C=dict.copy();D.dc_exec(G,C);F=[A for A in C.values()if callable(A)and getattr(A,'__dc_type',B)==j]
	if K(F)<1:raise Exception('No workflows found')
	return F[0]().spec()
def A1(path,index,name):
	with O(path)as P:
		E=G.load(P);S=A.parse(H.join(J(lambda c:H.join(c[Q]),E[R])));F=[B for B in A.walk(S)if C(B,(A.Import,A.ImportFrom))];I={A.asname or A.name for B in F for A in B.names};T=E[R][index][Q];B=A.parse(H.join(T));V=[E.id for D in A.walk(B)if C(D,A.Assign)for E in D.targets];W=[D.id for D in A.walk(B)if C(D,A.Name)and D.id not in V and D.id not in I];X={D.id for D in A.walk(B)if C(D,A.Name)};L=[A for A in F if K(set(J(lambda n:n.asname or n.name,A.names))&(I&X))>0];D=e();D.name=name
		for Y in U(dict.fromkeys(W)):M=A.arg();M.arg=Y;D.args.args.append(M)
		N=A.Return();N.value=B.body[-1].value;B.body[-1]=N;D.body=[B.body];A2(D);return a(f"from data_chimp_executor import execute as dchimp\n{A.unparse(L)}{os.linesep if K(L)>0 else''}\n{A.unparse(D)}\n")
def e():B=A.FunctionDef();B.args=A.arguments();B.args.args=[];B.args.posonlyargs=[];B.args.kwonlyargs=[];B.args.kw_defaults=[];B.args.defaults=[];B.decorator_list=[];B.lineno=0;return B
def A2(func):B=A.Attribute();B.value=A.Name(id='dchimp',ctx=A.Load());B.attr=i;func.decorator_list=[B]
def A3(path,index,name):
	M='snapshot'
	with O(path)as N:D=G.load(N);B=e();E=A.arg();E.arg=M;B.args.args.append(E);B.name=f"test_{name}";P=D[R][index][Q];F=A.parse(H.join(P));S=[D.id for B in A.walk(F)if C(B,A.Assign)for D in B.targets];I=A.parse(H.join(J(lambda c:H.join(c[Q]),D[R])));T=[B for B in A.walk(I)if C(B,(A.Import,A.ImportFrom))];V={A.asname or A.name for B in T for A in B.names};W={B.id for B in A.walk(F)if C(B,A.Name)and B.id not in S and B.id not in V};L={B for B in A.walk(I)if C(B,A.Assign)and K(W&set(J(lambda n:n.id,B.targets)))>0};X=[A.Name(C.id,A.Load())for B in L for C in B.targets];Y=A.Expr(A.Call(A.Attribute(A.Name(M,A.Load()),'assert_match',A.Load()),[A.Call(A.Name('repr',A.Load()),[A.Call(A.Name('task_one'),X,[])],[]),A.Constant(f"{name}_output.txt")],[]));B.body=U(L)+[Y];return a(f"import workflow\n{A.unparse(B)}\n            ")
def create_task(A,C,D):
	F=A1(A,C,D);E,J=os.path.split(A);G=os.path.join(E,'workflow.py')
	with O(G,mode='a')as B:B.write(F)
	H=os.path.join(E,'workflow_test.py');I=A3(A,C,D)
	with O(H,mode='a')as B:B.write(I)
def read_df(name,default=B):return S.DataFrame({'n_distinct_species':[5]})
def persist_df(name,df):0
def check_penguins(df):return df['species'].value_counts()