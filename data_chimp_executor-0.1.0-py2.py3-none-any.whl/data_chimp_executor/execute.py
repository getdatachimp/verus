m='cell_type'
l='task'
k='eval'
j='get_args'
i='combinations'
a='workflow'
Z='exec'
Y='code_snippets'
X='df'
W=map
V=list
S='cells'
R='<string>'
Q=open
P=str
N='id'
M=len
L=compile
K='source'
H='code'
G=False
F='\n'
E=True
C=isinstance
B=None
import linecache as n
from dataclasses import dataclass as b,asdict as o
from graphlib import TopologicalSorter as p
from inspect import getsource as c
from textwrap import dedent as d
import os as I,typing as q
from functools import wraps as e
import ast as A,json as J,pandas as T,re
from data_chimp_executor import open as D
from itertools import combinations as f
from IPython.display import display as g
def on_execute_cell(F,I,D):
	A=D.copy();C=J.loads(F,strict=G);C['target_id']='main_cmd';E=z(C[H],D)
	if E is not B:A[X]=E[1]
	A['dc_code']=C[H];s(I,A,E);K=r(C[H]);D.update({B:C for(B,C)in A.items()if B.startswith('_o')});return J.dumps({'contains_func_definition':K})
def r(code):
	try:
		B=A.parse(code)
		for D in A.walk(B):
			if C(D,A.FunctionDef):return E
	finally:return G
def s(json_automations,globals_dict,optional_df):
	D=globals_dict;A=optional_df;E=J.loads(json_automations,strict=G)
	for C in E:t(C,D,{N:C[N],'optional_df':A,Y:A2(C[H],A[0],A[1],D)if A is not B and A[0]is not B and A[1]is not B else B})
def t(cmd,globals_dict,metadata=B):u(cmd,globals_dict,metadata)
def u(cmd,globals_dict,metadata):
	E=metadata;B=globals_dict;C=A.parse(cmd[H])
	if v(C):F={};D.dc_exec(L(C,R,mode=Z),B|{i:f},F);w(B|F,E)
	else:D.dc_exec(L(C,R,mode=Z),B);x(C,B,E)
def v(root):
	B=G;D=G
	for F in A.walk(root):
		if not C(F,A.FunctionDef):continue
		match F.name:
			case'get_args':B=E
			case'visualize':D=E
	return B and D
def w(dict,metadata):
	B=dict[X];F=dict[j](B)
	for (C,G) in enumerate(F):A=metadata.copy();A['parent_id']=A[N];A[N]=A[N]+f"_{C}";A[Y]=A[Y][C];A['transient']=E;D=dict['visualize'](B,G);g(D.figure,metadata=A);D.clear()
def x(root,globals_dict,metadata):
	E=root.body.pop()
	if C(E,A.Assign):return B
	try:F=A.Expression(E.value);G=L(F,R,mode=k);g(D.dc_eval(G,globals_dict),metadata=metadata)
	except:return B
class y(A.NodeVisitor):
	def __init__(A,global_dict):A.globals_dict=global_dict;A.result=B
	def visit_Name(A,node):
		B=node;E=D.dc_eval(B.id,A.globals_dict)
		if C(E,T.DataFrame):A.result=B.id,D.dc_eval(B.id,A.globals_dict)
		else:A.generic_visit(B)
	def visit_Expr(B,node):
		E=A.Expression(node.value);G=L(E,R,mode=k);F=D.dc_eval(G,B.globals_dict)
		if C(F,T.DataFrame):B.result=A.unparse(E),F
		else:B.generic_visit(node)
def z(source,globals_dict):
	try:D=A.parse(source);C=y(globals_dict);C.visit(D);return C.result
	except:return B
class A0(A.NodeTransformer):
	def __init__(A,args):A.args=args
	def visit_Subscript(D,node):
		B=node;D.generic_visit(B)
		if C(B.value,A.Name)and B.value.id=='args':E=B.slice.value;return A.Constant(D.args[E])
		else:return B
class A1(A.NodeVisitor):
	def __init__(A,source_code,og_df_expression,og_df,global_dict):A.source_code=source_code;A.og_df_expression=og_df_expression;A.og_df=og_df;A.has_get_args_func=G;A.has_visualization_func=G;A.global_dict=global_dict
	def visit_FunctionDef(A,node):
		B=node
		match B.name:
			case'get_args':A.has_get_args_func=E;pass
			case'visualize':A.has_visualization_func=E;A.visualization_func_body=B.body;pass
		A.generic_visit(B)
	def code(C):
		if not C.has_get_args_func or not C.has_visualization_func:return B
		E={};D.dc_exec(C.source_code,C.global_dict|{i:f},E);F=E[j](C.og_df);G=[(B,A.parse(A.unparse(C.visualization_func_body)))for B in F];H=[A0(A).visit(B)for(A,B)in G];I=[A.unparse(B)for B in H];return[A.replace('return ','').replace(X,C.og_df_expression)for A in I]
def A2(code,og_df_expression,og_df,globals_dict):C=og_df_expression;B=code;E=A.parse(B);D=A1(B,C,og_df,globals_dict);D.visit(E);return D.code()or re.sub('^df',C,B)
@b(frozen=E)
class U:name:P;source:P;depends_on:P=B
@b
class A3:
	func:q.Callable;type:P;node:U=B;sorter=B;_sorted=B
	@property
	def sorted(self):
		A=self
		if A._sorted is B:
			C=[];A.sorter.prepare()
			while A.sorter.is_active():D=A.sorter.get_ready();C.append(D);A.sorter.done(*(D))
			A._sorted=C
		return A._sorted
	def __call__(A,*B,**C):return A.func(*(B),**C)
	def __rshift__(A,b):C=U(A.func.__name__,c(A.func))if A.node is B else A.node;D=U(b.func.__name__,c(b.func),C.name);E=A.sorter if A.sorter is not B else p();E.add(D,C);b.sorter=E;b.node=D;return b
	def spec(A):return J.dumps([V(W(o,B))for B in A.sorted])
def task(f):
	@e(f)
	def A(*A,**B):return f(*(A),**B)
	return A3(A,l)
def workflow(f):
	@e(f)
	def A(*A,**B):return f(*(A),**B)
	A.__dc_type=a;return A
def get_spec_from_module(str,dict):
	A='tmp_dc';G=L(str,A,Z);n.cache[A]=M(str),B,str.splitlines(E),A;C=dict.copy();D.dc_exec(G,C);F=[A for A in C.values()if callable(A)and getattr(A,'__dc_type',B)==a]
	if M(F)<1:raise Exception('No workflows found')
	return F[0]().spec()
def A4(path,index,name):
	with Q(path)as T:
		E=J.load(T);U=A.parse(F.join([F.join(A[K])for A in E[S]if not F.join(A[K]).startswith('%')and A[m]==H]));G=[B for B in A.walk(U)if C(B,(A.Import,A.ImportFrom))];L={A.asname or A.name for B in G for A in B.names};X=E[S][index][K];B=A.parse(F.join(X));Y=O(B);Z=[D.id for D in A.walk(B)if C(D,A.Name)and D.id not in Y and D.id not in L];a={D.id for D in A.walk(B)if C(D,A.Name)};N=[A for A in G if M(set(W(lambda n:n.asname or n.name,A.names))&(L&a))>0];D=h();D.name=name
		for b in V(dict.fromkeys(Z)):P=A.arg();P.arg=b;D.args.args.append(P)
		R=A.Return();R.value=B.body[-1].value;B.body[-1]=R;D.body=[B.body];A5(D);return d(f"from data_chimp_executor import execute as dchimp\n{A.unparse(N)}{I.linesep if M(N)>0 else''}\n{A.unparse(D)}\n")
def O(parsed):
	D=[]
	for E in A.walk(parsed):
		if C(E,A.Assign):
			for B in E.targets:
				if C(B,A.Name):D.append(B.id)
				elif C(B,A.Tuple):D.extend(W(lambda n:n.id,B.elts))
	return D
def h():B=A.FunctionDef();B.args=A.arguments();B.args.args=[];B.args.posonlyargs=[];B.args.kwonlyargs=[];B.args.kw_defaults=[];B.args.defaults=[];B.decorator_list=[];B.lineno=0;return B
def A5(func):B=A.Attribute();B.value=A.Name(id='dchimp',ctx=A.Load());B.attr=l;func.decorator_list=[B]
def A6(path,index,name):
	P='snapshot';D=name
	with Q(path)as R:E=J.load(R);B=h();G=A.arg();G.arg=P;B.args.args.append(G);B.name=f"test_{D}";T=E[S][index][K];I=A.parse(F.join(T));U=O(I);L=A.parse(F.join([F.join(A[K])for A in E[S]if not F.join(A[K]).startswith('%')and A[m]==H]));W=[B for B in A.walk(L)if C(B,(A.Import,A.ImportFrom))];X={A.asname or A.name for B in W for A in B.names};Y={B.id for B in A.walk(I)if C(B,A.Name)and B.id not in U and B.id not in X};N={B for B in A.walk(L)if C(B,A.Assign)and M(Y&set(O(B)))>0};Z=[A.Name(C,A.Load())for B in N for C in O(B)];b=A.Expr(A.Call(A.Attribute(A.Name(P,A.Load()),'assert_match',A.Load()),[A.Call(A.Name('repr',A.Load()),[A.Call(A.Attribute(A.Name(a,A.Load()),D,A.Load()),Z,[])],[]),A.Constant(f"{D}_output.txt")],[]));B.body=V(N)+[b];return d(f"import workflow\n{A.unparse(B)}\n            ")
def create_task(C,E,F):
	A=A4(C,E,F);G,K=I.path.split(C);H=I.path.join(G,'workflow.py');A=A if not I.path.exists(H)else A.replace('from data_chimp_executor import execute as dchimp\n','')
	with Q(H,mode='a')as D:D.write(A)
	J=I.path.join(G,'workflow_test.py');B=A6(C,E,F);B=B if not I.path.exists(J)else B.replace('import workflow\n','')
	with Q(J,mode='a')as D:D.write(B)
def read_df(name,default=B):return T.DataFrame({'n_distinct_species':[5]})
def persist_df(name,df):0
def check_penguins(df):return df['species'].value_counts()