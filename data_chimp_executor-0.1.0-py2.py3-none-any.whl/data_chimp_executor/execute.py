k='task'
j='eval'
i='get_args'
h='combinations'
Z='workflow'
Y='exec'
X='code_snippets'
W='df'
V=map
U=list
R='cells'
Q='<string>'
P=open
O=str
N='id'
M='code'
L=len
K=compile
J='source'
G=False
F='\n'
E=True
C=isinstance
B=None
import linecache as l
from dataclasses import dataclass as a,asdict as m
from graphlib import TopologicalSorter as n
from inspect import getsource as c
from textwrap import dedent as b
import os as H,typing as o
from functools import wraps as d
import ast as A,json as I,pandas as S,re
from data_chimp_executor import open as D
from itertools import combinations as e
from IPython.display import display as f
def on_execute_cell(F,H,D):
	A=D.copy();C=I.loads(F,strict=G);C['target_id']='main_cmd';E=x(C[M],D)
	if E is not B:A[W]=E[1]
	A['dc_code']=C[M];q(H,A,E);J=p(C[M]);D.update({B:C for(B,C)in A.items()if B.startswith('_o')});return I.dumps({'contains_func_definition':J})
def p(code):
	try:
		B=A.parse(code)
		for D in A.walk(B):
			if C(D,A.FunctionDef):return E
	finally:return G
def q(json_automations,globals_dict,optional_df):
	D=globals_dict;A=optional_df;E=I.loads(json_automations,strict=G)
	for C in E:r(C,D,{N:C[N],'optional_df':A,X:A0(C[M],A[0],A[1],D)if A is not B and A[0]is not B and A[1]is not B else B})
def r(cmd,globals_dict,metadata=B):s(cmd,globals_dict,metadata)
def s(cmd,globals_dict,metadata):
	E=metadata;B=globals_dict;C=A.parse(cmd[M])
	if t(C):F={};D.dc_exec(K(C,Q,mode=Y),B|{h:e},F);u(B|F,E)
	else:D.dc_exec(K(C,Q,mode=Y),B);v(C,B,E)
def t(root):
	B=G;D=G
	for F in A.walk(root):
		if not C(F,A.FunctionDef):continue
		match F.name:
			case'get_args':B=E
			case'visualize':D=E
	return B and D
def u(dict,metadata):
	B=dict[W];F=dict[i](B)
	for (C,G) in enumerate(F):A=metadata.copy();A['parent_id']=A[N];A[N]=A[N]+f"_{C}";A[X]=A[X][C];A['transient']=E;D=dict['visualize'](B,G);f(D.figure,metadata=A);D.clear()
def v(root,globals_dict,metadata):
	E=root.body.pop()
	if C(E,A.Assign):return B
	try:F=A.Expression(E.value);G=K(F,Q,mode=j);f(D.dc_eval(G,globals_dict),metadata=metadata)
	except:return B
class w(A.NodeVisitor):
	def __init__(A,global_dict):A.globals_dict=global_dict;A.result=B
	def visit_Name(A,node):
		B=node;E=D.dc_eval(B.id,A.globals_dict)
		if C(E,S.DataFrame):A.result=B.id,D.dc_eval(B.id,A.globals_dict)
		else:A.generic_visit(B)
	def visit_Expr(B,node):
		E=A.Expression(node.value);G=K(E,Q,mode=j);F=D.dc_eval(G,B.globals_dict)
		if C(F,S.DataFrame):B.result=A.unparse(E),F
		else:B.generic_visit(node)
def x(source,globals_dict):
	try:D=A.parse(source);C=w(globals_dict);C.visit(D);return C.result
	except:return B
class y(A.NodeTransformer):
	def __init__(A,args):A.args=args
	def visit_Subscript(D,node):
		B=node;D.generic_visit(B)
		if C(B.value,A.Name)and B.value.id=='args':E=B.slice.value;return A.Constant(D.args[E])
		else:return B
class z(A.NodeVisitor):
	def __init__(A,source_code,og_df_expression,og_df,global_dict):A.source_code=source_code;A.og_df_expression=og_df_expression;A.og_df=og_df;A.has_get_args_func=G;A.has_visualization_func=G;A.global_dict=global_dict
	def visit_FunctionDef(A,node):
		B=node
		match B.name:
			case'get_args':A.has_get_args_func=E;pass
			case'visualize':A.has_visualization_func=E;A.visualization_func_body=B.body;pass
		A.generic_visit(B)
	def code(C):
		if not C.has_get_args_func or not C.has_visualization_func:return B
		E={};D.dc_exec(C.source_code,C.global_dict|{h:e},E);F=E[i](C.og_df);G=[(B,A.parse(A.unparse(C.visualization_func_body)))for B in F];H=[y(A).visit(B)for(A,B)in G];I=[A.unparse(B)for B in H];return[A.replace('return ','').replace(W,C.og_df_expression)for A in I]
def A0(code,og_df_expression,og_df,globals_dict):C=og_df_expression;B=code;E=A.parse(B);D=z(B,C,og_df,globals_dict);D.visit(E);return D.code()or re.sub('^df',C,B)
@a(frozen=E)
class T:name:O;source:O;depends_on:O=B
@a
class A1:
	func:o.Callable;type:O;node:T=B;sorter=B;_sorted=B
	@property
	def sorted(self):
		A=self
		if A._sorted is B:
			C=[];A.sorter.prepare()
			while A.sorter.is_active():D=A.sorter.get_ready();C.append(D);A.sorter.done(*(D))
			A._sorted=C
		return A._sorted
	def __call__(A,*B,**C):return A.func(*(B),**C)
	def __rshift__(A,b):C=T(A.func.__name__,c(A.func))if A.node is B else A.node;D=T(b.func.__name__,c(b.func),C.name);E=A.sorter if A.sorter is not B else n();E.add(D,C);b.sorter=E;b.node=D;return b
	def spec(A):return I.dumps([U(V(m,B))for B in A.sorted])
def task(f):
	@d(f)
	def A(*A,**B):return f(*(A),**B)
	return A1(A,k)
def workflow(f):
	@d(f)
	def A(*A,**B):return f(*(A),**B)
	A.__dc_type=Z;return A
def get_spec_from_module(str,dict):
	A='tmp_dc';G=K(str,A,Y);l.cache[A]=L(str),B,str.splitlines(E),A;C=dict.copy();D.dc_exec(G,C);F=[A for A in C.values()if callable(A)and getattr(A,'__dc_type',B)==Z]
	if L(F)<1:raise Exception('No workflows found')
	return F[0]().spec()
def A2(path,index,name):
	with P(path)as Q:
		E=I.load(Q);S=A.parse(F.join([F.join(A[J])for A in E[R]if not F.join(A[J]).startswith('%')]));G=[B for B in A.walk(S)if C(B,(A.Import,A.ImportFrom))];K={A.asname or A.name for B in G for A in B.names};T=E[R][index][J];B=A.parse(F.join(T));W=[E.id for D in A.walk(B)if C(D,A.Assign)for E in D.targets];X=[D.id for D in A.walk(B)if C(D,A.Name)and D.id not in W and D.id not in K];Y={D.id for D in A.walk(B)if C(D,A.Name)};M=[A for A in G if L(set(V(lambda n:n.asname or n.name,A.names))&(K&Y))>0];D=g();D.name=name
		for Z in U(dict.fromkeys(X)):N=A.arg();N.arg=Z;D.args.args.append(N)
		O=A.Return();O.value=B.body[-1].value;B.body[-1]=O;D.body=[B.body];A3(D);return b(f"from data_chimp_executor import execute as dchimp\n{A.unparse(M)}{H.linesep if L(M)>0 else''}\n{A.unparse(D)}\n")
def g():B=A.FunctionDef();B.args=A.arguments();B.args.args=[];B.args.posonlyargs=[];B.args.kwonlyargs=[];B.args.kw_defaults=[];B.args.defaults=[];B.decorator_list=[];B.lineno=0;return B
def A3(func):B=A.Attribute();B.value=A.Name(id='dchimp',ctx=A.Load());B.attr=k;func.decorator_list=[B]
def A4(path,index,name):
	N='snapshot';D=name
	with P(path)as O:E=I.load(O);B=g();G=A.arg();G.arg=N;B.args.args.append(G);B.name=f"test_{D}";Q=E[R][index][J];H=A.parse(F.join(Q));S=[D.id for B in A.walk(H)if C(B,A.Assign)for D in B.targets];K=A.parse(F.join([F.join(A[J])for A in E[R]if not F.join(A[J]).startswith('%')]));T=[B for B in A.walk(K)if C(B,(A.Import,A.ImportFrom))];W={A.asname or A.name for B in T for A in B.names};X={B.id for B in A.walk(H)if C(B,A.Name)and B.id not in S and B.id not in W};M={B for B in A.walk(K)if C(B,A.Assign)and L(X&set(V(lambda n:n.id,B.targets)))>0};Y=[A.Name(C.id,A.Load())for B in M for C in B.targets];a=A.Expr(A.Call(A.Attribute(A.Name(N,A.Load()),'assert_match',A.Load()),[A.Call(A.Name('repr',A.Load()),[A.Call(A.Attribute(A.Name(Z,A.Load()),D,A.Load()),Y,[])],[]),A.Constant(f"{D}_output.txt")],[]));B.body=U(M)+[a];return b(f"import workflow\n{A.unparse(B)}\n            ")
def create_task(C,E,F):
	A=A2(C,E,F);G,K=H.path.split(C);I=H.path.join(G,'workflow.py');A=A if not H.path.exists(I)else A.replace('from data_chimp_executor import execute as dchimp\n','')
	with P(I,mode='a')as D:D.write(A)
	J=H.path.join(G,'workflow_test.py');B=A4(C,E,F);B=B if not H.path.exists(J)else B.replace('import workflow\n','')
	with P(J,mode='a')as D:D.write(B)
def read_df(name,default=B):return S.DataFrame({'n_distinct_species':[5]})
def persist_df(name,df):0
def check_penguins(df):return df['species'].value_counts()