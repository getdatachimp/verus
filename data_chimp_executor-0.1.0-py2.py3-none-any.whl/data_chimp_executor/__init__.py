__author__='Matt Dupree'
__email__='matt@datachimp.app'
__version__='0.1.0'